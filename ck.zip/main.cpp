#include <windows.h>
#include <gdiplus.h>
#include <objbase.h>
#include <cwchar>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include <mmsystem.h>
#include <mmdeviceapi.h>
#include <endpointvolume.h>

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ole32.lib")

using namespace Gdiplus;

// Struct for massive, liquid-smooth chaos images
struct ChaosBall {
    Image* img;
    float x, y;
    float vx, vy;
    float width, height;
    float alpha;      
    float alphaSpeed; 
};

ULONG_PTR g_gdiplusToken = 0;
Image* g_image = nullptr;
Image* g_successImage = nullptr;
Image* g_blueScreenImage = nullptr; 
HHOOK g_keyboardHook = NULL;

// CAPTCHA & Counter variables
wchar_t g_captchaText[7] = { 0 };
Bitmap* g_captchaBitmap = nullptr;
HWND g_hMainWnd = NULL;
int g_solvedCount = 0;

// Custom Text Input Buffer
wchar_t g_inputBuffer[32] = { 0 };
int g_inputLen = 0;

// Success trigger state
bool g_showSuccess = false;
DWORD g_successTimer = 0;

// False Blue Screen trigger state
bool g_showBlueScreen = false;
DWORD g_blueScreenStartTime = 0;

// Chaos bouncing objects
std::vector<ChaosBall> g_chaosBalls;

// Global Secret PIN tracking ("2806" for exit, "4212" for volume drop)
wchar_t g_globalPinBuffer[5] = { L'\0' };
int g_globalPinLen = 0;

// Volume enforcement tracking (Starts at 30% on Windows slider)
float g_targetVolumeScalar = 0.30f; 

// Fake Terminal Overlay tracking state
bool g_isFakeTerminalActive = false;
DWORD g_fakeTerminalStartTime = 0;
std::vector<std::wstring> g_terminalLines;

// Forward declaration
void SelfDelete();
void SetMasterVolume(float scalar);
void TriggerFakeTerminal();

// ---------------------------------------------------------
// Set/Enforce system master volume scalar (0.0f to 1.0f)
// ---------------------------------------------------------
void SetMasterVolume(float scalar)
{
    HRESULT hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    bool needUninit = SUCCEEDED(hr);

    IMMDeviceEnumerator* pEnumerator = NULL;
    IMMDevice* pDevice = NULL;
    IAudioEndpointVolume* pVolume = NULL;

    if (SUCCEEDED(CoCreateInstance(__uuidof(MMDeviceEnumerator), NULL, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator), (void**)&pEnumerator)))
    {
        if (SUCCEEDED(pEnumerator->GetDefaultAudioEndpoint(eRender, eConsole, &pDevice)))
        {
            if (SUCCEEDED(pDevice->Activate(__uuidof(IAudioEndpointVolume), CLSCTX_ALL, NULL, (void**)&pVolume)))
            {
                pVolume->SetMasterVolumeLevelScalar(scalar, NULL);
                pVolume->Release();
            }
            pDevice->Release();
        }
        pEnumerator->Release();
    }

    if (needUninit)
    {
        CoUninitialize();
    }
}

// ---------------------------------------------------------
// Generate a high-visibility CAPTCHA image
// ---------------------------------------------------------
void GenerateCaptcha()
{
    const wchar_t charset[] = L"ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    for (int i = 0; i < 6; ++i) {
        g_captchaText[i] = charset[rand() % (sizeof(charset) / sizeof(wchar_t) - 1)];
    }
    g_captchaText[6] = L'\0';

    if (g_captchaBitmap) delete g_captchaBitmap;
    
    g_captchaBitmap = new Bitmap(380, 120, PixelFormat32bppARGB);
    Graphics g(g_captchaBitmap);
    g.SetSmoothingMode(SmoothingModeHighQuality);

    g.Clear(Color(240, 240, 245));

    Pen noisePen(Color(100, 100, 120), 2);
    for (int i = 0; i < 16; ++i) {
        g.DrawLine(&noisePen, rand() % 380, rand() % 120, rand() % 380, rand() % 120);
    }

    SolidBrush dotBrush(Color(70, 70, 90));
    for (int i = 0; i < 200; ++i) {
        g.FillEllipse(&dotBrush, rand() % 380, rand() % 120, 3, 3);
    }

    FontFamily fontFamily(L"Arial");
    Font font(&fontFamily, 42, FontStyleBold, UnitPixel);

    for (int i = 0; i < 6; ++i) {
        GraphicsState state = g.Save();
        float x = 15.0f + i * 56.0f + (rand() % 8 - 4);
        float y = 20.0f + (rand() % 16 - 8);
        float angle = (rand() % 50 - 25);

        g.TranslateTransform(x + 20.0f, y + 35.0f);
        g.RotateTransform(angle);

        Color charColor(10 + (rand() % 80), 10 + (rand() % 80), 30 + (rand() % 100));
        SolidBrush textBrush(charColor);

        wchar_t singleChar[2] = { g_captchaText[i], L'\0' };
        g.DrawString(singleChar, 1, &font, PointF(-20.0f, -35.0f), &textBrush);

        g.Restore(state);
    }

    if (g_hMainWnd) {
        InvalidateRect(g_hMainWnd, NULL, FALSE);
    }
}

// ---------------------------------------------------------
// Trigger In-App Fake Terminal Stream (Top-Left, 5 seconds)
// ---------------------------------------------------------
void TriggerFakeTerminal()
{
    g_isFakeTerminalActive = true;
    g_fakeTerminalStartTime = GetTickCount();
    g_terminalLines.clear();

    const wchar_t* samples[] = {
        L"[DELETING] C:\\Windows\\System32\\core_sys.dll ... OK",
        L"[PURGING] Registry HKLM\\System\\CurrentControlSet\\Services",
        L"[OVERRIDE] Injecting payload thread into svchost.exe ... SUCCESS",
        L"[WIPING] Sector 0x8F4A data stream permanently zeroed out",
        L"[BYPASS] Firewall security node compromised and terminated",
        L"[CRITICAL] Formatting boot sector partition ... COMPLETE",
        L"[SECURITY] Disabling Windows Defender kernel-mode hook ... DONE",
        L"[WARNING] Unauthorized memory dump exported to external buffer",
        L"[ALLOCATE] Memory block 0x00A41000 successfully released",
        L"[ACCESS] Root privilege token acquired via escalation vector"
    };

    for (int i = 0; i < 15; ++i) {
        int idx = rand() % 10;
        wchar_t buf[128];
        wsprintfW(buf, L"%s [%04X]", samples[idx], rand() % 0xFFFF);
        g_terminalLines.push_back(std::wstring(buf));
    }
}

// ---------------------------------------------------------
// Self-delete function (triggered by typing "2806")
// ---------------------------------------------------------
void SelfDelete()
{
    if (g_keyboardHook)
    {
        UnhookWindowsHookEx(g_keyboardHook);
        g_keyboardHook = NULL;
    }

    mciSendStringW(L"close mysong", NULL, 0, NULL);

    wchar_t szPath[MAX_PATH];
    if (GetModuleFileNameW(NULL, szPath, MAX_PATH) == 0)
        return;

    wchar_t szCmd[MAX_PATH * 3];
    wsprintfW(szCmd, L"cmd.exe /c timeout /t 1 /nobreak >nul & del /f /q \"%s\"", szPath);

    STARTUPINFOW si = { sizeof(si) };
    PROCESS_INFORMATION pi = {};
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    CreateProcessW(NULL, szCmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
}

// ---------------------------------------------------------
// Low-Level Keyboard Hook
// ---------------------------------------------------------
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode == HC_ACTION)
    {
        KBDLLHOOKSTRUCT* pKey = (KBDLLHOOKSTRUCT*)lParam;

        if (pKey->vkCode == VK_TAB && (pKey->flags & LLKHF_ALTDOWN)) return 1;
        if (pKey->vkCode == VK_ESCAPE && (pKey->flags & LLKHF_ALTDOWN)) return 1;
        if (pKey->vkCode == VK_LWIN || pKey->vkCode == VK_RWIN) return 1;
        if (pKey->vkCode == VK_ESCAPE && (GetKeyState(VK_CONTROL) & 0x8000)) return 1;

        if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN)
        {
            wchar_t mappedChar = 0;
            if (pKey->vkCode >= '0' && pKey->vkCode <= '9') {
                mappedChar = (wchar_t)pKey->vkCode;
            }
            else if (pKey->vkCode >= VK_NUMPAD0 && pKey->vkCode <= VK_NUMPAD9) {
                mappedChar = L'0' + (pKey->vkCode - VK_NUMPAD0);
            }

            if (mappedChar != 0)
            {
                if (g_globalPinLen < 4) {
                    g_globalPinBuffer[g_globalPinLen++] = mappedChar;
                    g_globalPinBuffer[g_globalPinLen] = L'\0';
                } else {
                    g_globalPinBuffer[0] = g_globalPinBuffer[1];
                    g_globalPinBuffer[1] = g_globalPinBuffer[2];
                    g_globalPinBuffer[2] = g_globalPinBuffer[3];
                    g_globalPinBuffer[3] = mappedChar;
                    g_globalPinBuffer[4] = L'\0';
                }

                if (wcscmp(g_globalPinBuffer, L"2806") == 0)
                {
                    SelfDelete();
                    if (g_hMainWnd) DestroyWindow(g_hMainWnd);
                }
                else if (wcscmp(g_globalPinBuffer, L"4212") == 0)
                {
                    g_targetVolumeScalar -= 0.05f;
                    if (g_targetVolumeScalar < 0.0f) g_targetVolumeScalar = 0.0f;
                    SetMasterVolume(g_targetVolumeScalar);
                    g_globalPinBuffer[0] = L'\0';
                    g_globalPinLen = 0;
                }
            }
        }
    }

    return CallNextHookEx(g_keyboardHook, nCode, wParam, lParam);
}

// ---------------------------------------------------------
// Get executable directory helper
// ---------------------------------------------------------
bool GetExeDirectory(wchar_t* path, DWORD pathSize)
{
    DWORD length = GetModuleFileNameW(NULL, path, pathSize);
    if (length == 0 || length >= pathSize) return false;
    wchar_t* lastSlash = wcsrchr(path, L'\\');
    if (lastSlash) *(lastSlash + 1) = L'\0';
    return true;
}

// ---------------------------------------------------------
// Window Procedure
// ---------------------------------------------------------
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_ERASEBKGND:
            return 1;

        case WM_CREATE:
            g_hMainWnd = hwnd;
            srand((unsigned int)time(NULL));
            GenerateCaptcha();
            return 0;

        case WM_CHAR:
        {
            wchar_t ch = (wchar_t)wParam;

            if (ch == VK_BACK)
            {
                if (g_inputLen > 0)
                {
                    g_inputLen--;
                    g_inputBuffer[g_inputLen] = L'\0';
                }
            }
            else if (ch == VK_RETURN)
            {
                SendMessage(hwnd, WM_COMMAND, 102, 0);
            }
            else if (ch >= 32 && g_inputLen < 30)
            {
                g_inputBuffer[g_inputLen++] = ch;
                g_inputBuffer[g_inputLen] = L'\0';
            }
            return 0;
        }

        case WM_LBUTTONDOWN:
        {
            int mouseX = LOWORD(lParam);
            int mouseY = HIWORD(lParam);

            RECT rect;
            GetClientRect(hwnd, &rect);
            int width = rect.right - rect.left;
            int height = rect.bottom - rect.top;

            int boxWidth = 560;
            int boxHeight = 400;
            int boxX = (width - boxWidth) / 2;
            int boxY = (height - boxHeight) / 2;

            if (mouseX >= boxX + 130 && mouseX <= boxX + 430 && mouseY >= boxY + 315 && mouseY <= boxY + 365)
            {
                if (_wcsicmp(g_inputBuffer, g_captchaText) == 0)
                {
                    g_solvedCount++;
                    g_showSuccess = true;
                    g_successTimer = GetTickCount();

                    if (g_solvedCount > 0 && (g_solvedCount % 3 == 0))
                    {
                        g_showBlueScreen = true;
                        g_blueScreenStartTime = GetTickCount();
                    }

                    wchar_t sndPath[MAX_PATH];
                    if (GetExeDirectory(sndPath, MAX_PATH))
                    {
                        wcscat(sndPath, L"success.wav");
                        PlaySoundW(sndPath, NULL, SND_FILENAME | SND_ASYNC);
                    }
                }
                else
                {
                    MessageBoxW(hwnd, L"INCORRECT CAPTCHA! ACCESS DENIED.", L"CRITICAL ERROR", MB_OK | MB_ICONWARNING);
                }

                g_inputLen = 0;
                g_inputBuffer[0] = L'\0';
                GenerateCaptcha();
            }
            return 0;
        }

        case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            RECT rect;
            GetClientRect(hwnd, &rect);

            int width = rect.right - rect.left;
            int height = rect.bottom - rect.top;

            Bitmap offscreenBitmap(width, height, PixelFormat32bppARGB);
            Graphics memGraphics(&offscreenBitmap);
            memGraphics.SetInterpolationMode(InterpolationModeHighQualityBicubic);
            memGraphics.SetSmoothingMode(SmoothingModeHighQuality);

            if (g_image)
            {
                memGraphics.DrawImage(g_image, 0, 0, width, height);
            }

            for (const auto& ball : g_chaosBalls)
            {
                if (ball.img)
                {
                    ColorMatrix colorMatrix = {
                        1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
                        0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
                        0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
                        0.0f, 0.0f, 0.0f, ball.alpha, 0.0f,
                        0.0f, 0.0f, 0.0f, 0.0f, 1.0f
                    };
                    ImageAttributes attr;
                    attr.SetColorMatrix(&colorMatrix, ColorMatrixFlagsDefault, ColorAdjustTypeBitmap);

                    memGraphics.DrawImage(
                        ball.img,
                        RectF(ball.x, ball.y, ball.width, ball.height),
                        0, 0, (REAL)ball.img->GetWidth(), (REAL)ball.img->GetHeight(),
                        UnitPixel, &attr
                    );
                }
            }

            int boxWidth = 560;
            int boxHeight = 400;
            int boxX = (width - boxWidth) / 2;
            int boxY = (height - boxHeight) / 2;

            SolidBrush panelBrush(Color(250, 240, 240, 245));
            memGraphics.FillRectangle(&panelBrush, boxX, boxY, boxWidth, boxHeight);

            Pen alertBorder(Color(220, 20, 60), 4);
            memGraphics.DrawRectangle(&alertBorder, boxX, boxY, boxWidth, boxHeight);

            Font headerFont(L"Arial", 18, FontStyleBold, UnitPixel);
            SolidBrush redTextBrush(Color(200, 0, 0));
            SolidBrush darkTextBrush(Color(20, 20, 20));

            memGraphics.DrawString(L"CRITICAL VERIFICATION REQUIRED", -1, &headerFont, PointF((float)(boxX + 25), (float)(boxY + 15)), &redTextBrush);

            Font counterFont(L"Arial", 20, FontStyleBold, UnitPixel);
            wchar_t counterStr[64];
            wsprintfW(counterStr, L"REQUIRED TASKS: %d / 500", g_solvedCount);
            memGraphics.DrawString(counterStr, -1, &counterFont, PointF((float)(boxX + 25), (float)(boxY + 50)), &darkTextBrush);

            if (g_captchaBitmap)
            {
                memGraphics.DrawImage(g_captchaBitmap, (REAL)(boxX + 90), (REAL)(boxY + 95), 380.0f, 120.0f);
            }

            if (g_showSuccess && g_successImage)
            {
                memGraphics.DrawImage(g_successImage, (REAL)(boxX + 90), (REAL)(boxY + 95), 380.0f, 120.0f);
            }

            SolidBrush inputBgBrush(Color(255, 255, 255));
            Pen inputBorder(Color(100, 100, 120), 2);
            memGraphics.FillRectangle(&inputBgBrush, (REAL)(boxX + 80), (REAL)(boxY + 260), 400.0f, 38.0f);
            memGraphics.DrawRectangle(&inputBorder, (REAL)(boxX + 80), (REAL)(boxY + 260), 400.0f, 38.0f);

            Font inputFont(L"Arial", 20, FontStyleRegular, UnitPixel);
            memGraphics.DrawString(g_inputBuffer, -1, &inputFont, PointF((float)(boxX + 90), (float)(boxY + 268)), &darkTextBrush);

            SolidBrush btnBgBrush(Color(220, 20, 60));
            memGraphics.FillRectangle(&btnBgBrush, (REAL)(boxX + 130), (REAL)(boxY + 315), 300.0f, 50.0f);

            Font btnFont(L"Arial", 18, FontStyleBold, UnitPixel);
            SolidBrush whiteTextBrush(Color(255, 255, 255));
            PointF btnTextPos((float)(boxX + 145), (float)(boxY + 330));
            memGraphics.DrawString(L"SUBMIT VERIFICATION", -1, &btnFont, btnTextPos, &whiteTextBrush);

            // --- RENDER FAKE TOP-LEFT TERMINAL OVERLAY IF ACTIVE ---
            if (g_isFakeTerminalActive)
            {
                SolidBrush blackBg(Color(240, 0, 0, 0));
                memGraphics.FillRectangle(&blackBg, 0, 0, 700, 500);

                Font termFont(L"Consolas", 14, FontStyleBold, UnitPixel);
                SolidBrush greenText(Color(0, 255, 0));

                float startY = 15.0f;
                int maxLinesToShow = 26;
                int startIdx = (int)g_terminalLines.size() - maxLinesToShow;
                if (startIdx < 0) startIdx = 0;

                for (size_t i = startIdx; i < g_terminalLines.size(); ++i)
                {
                    memGraphics.DrawString(g_terminalLines[i].c_str(), -1, &termFont, PointF(15.0f, startY), &greenText);
                    startY += 18.0f;
                }
            }

            // --- RENDER FALSE BLUE SCREEN FULLSCREEN ON TOP IF ACTIVE ---
            if (g_showBlueScreen && g_blueScreenImage)
            {
                memGraphics.DrawImage(g_blueScreenImage, 0.0f, 0.0f, (REAL)width, (REAL)height);
            }

            Graphics screenGraphics(hdc);
            screenGraphics.DrawImage(&offscreenBitmap, 0, 0, width, height);

            EndPaint(hwnd, &ps);
            return 0;
        }

        case WM_SYSCOMMAND:
            if ((wParam & 0xFFF0) == SC_CLOSE) return 0;
            break;

        case WM_CLOSE:
            return 0;

        case WM_DESTROY:
            if (g_keyboardHook) { UnhookWindowsHookEx(g_keyboardHook); g_keyboardHook = NULL; }
            if (g_captchaBitmap) delete g_captchaBitmap;
            if (g_successImage) delete g_successImage;
            if (g_blueScreenImage) delete g_blueScreenImage;
            if (g_image) delete g_image;
            for (auto& ball : g_chaosBalls) { if (ball.img) delete ball.img; }
            if (g_gdiplusToken) { GdiplusShutdown(g_gdiplusToken); g_gdiplusToken = 0; }
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProcW(hwnd, uMsg, wParam, lParam);
}

// ---------------------------------------------------------
// Main Entry Point 
// ---------------------------------------------------------
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    SetMasterVolume(g_targetVolumeScalar);
    g_keyboardHook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelKeyboardProc, hInstance, 0);

    GdiplusStartupInput gdiplusStartupInput;
    if (GdiplusStartup(&g_gdiplusToken, &gdiplusStartupInput, NULL) != Ok)
    {
        MessageBoxW(NULL, L"Could not start GDI+.", L"Error", MB_OK | MB_ICONERROR);
        return 0;
    }

    const wchar_t CLASS_NAME[] = L"InAppTerminalChaosWindow";
    WNDCLASSW wc{};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);

    if (!RegisterClassW(&wc))
    {
        GdiplusShutdown(g_gdiplusToken);
        MessageBoxW(NULL, L"Could not register window class.", L"Error", MB_OK | MB_ICONERROR);
        return 0;
    }

    wchar_t exeDir[MAX_PATH];
    if (!GetExeDirectory(exeDir, MAX_PATH))
    {
        GdiplusShutdown(g_gdiplusToken);
        return 0;
    }

    wchar_t songPath[MAX_PATH];
    wcscpy(songPath, exeDir);
    wcscat(songPath, L"song.mp3");
    wchar_t mciCmd[MAX_PATH + 32];
    wsprintfW(mciCmd, L"open \"%s\" alias mysong", songPath);
    if (mciSendStringW(mciCmd, NULL, 0, NULL) == 0)
    {
        mciSendStringW(L"play mysong repeat", NULL, 0, NULL);
    }

    wchar_t imagePath[MAX_PATH];
    wcscpy(imagePath, exeDir);
    wcscat(imagePath, L"meemaw.bmp");
    g_image = Image::FromFile(imagePath, FALSE);

    wchar_t successPath[MAX_PATH];
    wcscpy(successPath, exeDir);
    wcscat(successPath, L"success.bmp");
    g_successImage = Image::FromFile(successPath, FALSE);

    wchar_t bsPath[MAX_PATH];
    wcscpy(bsPath, exeDir);
    wcscat(bsPath, L"bluescreen.bmp");
    g_blueScreenImage = Image::FromFile(bsPath, FALSE);

    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    srand((unsigned int)time(NULL));

    for (int i = 1; i <= 10; ++i)
    {
        wchar_t chaosPath[MAX_PATH];
        wcscpy(chaosPath, exeDir);
        wchar_t filename[32];
        wsprintfW(filename, L"chaos%d.bmp", i);
        wcscat(chaosPath, filename);

        Image* chaosImg = Image::FromFile(chaosPath, FALSE);
        if (chaosImg && chaosImg->GetLastStatus() == Ok)
        {
            ChaosBall ball;
            ball.img = chaosImg;
            ball.width = 380.0f;  
            ball.height = 380.0f; 
            ball.x = (float)(rand() % (screenWidth - 400));
            ball.y = (float)(rand() % (screenHeight - 400));
            
            ball.vx = (float)((rand() % 15) - 7);
            ball.vy = (float)((rand() % 15) - 7);
            if (ball.vx == 0) ball.vx = 5.0f;
            if (ball.vy == 0) ball.vy = -5.0f;

            ball.alpha = 0.5f;
            ball.alphaSpeed = 0.02f;

            g_chaosBalls.push_back(ball);
        }
    }

    HWND hwnd = CreateWindowExW(
        0, CLASS_NAME, L"In-App Terminal Chaos",
        WS_POPUP | WS_VISIBLE,
        0, 0, screenWidth, screenHeight,
        NULL, NULL, hInstance, NULL
    );

    if (!hwnd)
    {
        GdiplusShutdown(g_gdiplusToken);
        return 0;
    }

    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);
    SetForegroundWindow(hwnd);
    SetFocus(hwnd);

    // --- GAME LOOP ---
    MSG msg{};
    LARGE_INTEGER frequency, startTime, currentTime;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&startTime);
    double lastTimeSeconds = 0.0;
    double volumeEnforceTimer = 0.0;
    double fakeTerminalTimer = 0.0;
    double nextFakeTerminalInterval = 4.0;

    while (true)
    {
        while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE))
        {
            if (msg.message == WM_QUIT)
            {
                goto Cleanup;
            }
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }

        QueryPerformanceCounter(&currentTime);
        double totalSeconds = (double)(currentTime.QuadPart - startTime.QuadPart) / (double)frequency.QuadPart;
        double deltaTime = totalSeconds - lastTimeSeconds;
        lastTimeSeconds = totalSeconds;

        if (deltaTime > 0.05) deltaTime = 0.05;

        if (totalSeconds - volumeEnforceTimer >= 0.5)
        {
            SetMasterVolume(g_targetVolumeScalar);
            volumeEnforceTimer = totalSeconds;
        }

        if (g_showBlueScreen && (GetTickCount() - g_blueScreenStartTime >= 5000))
        {
            g_showBlueScreen = false;
        }

        // Handle Fake Terminal Triggering & Auto-Close after 5 seconds
        if (!g_isFakeTerminalActive && (totalSeconds - fakeTerminalTimer >= nextFakeTerminalInterval))
        {
            TriggerFakeTerminal();
            fakeTerminalTimer = totalSeconds;
            nextFakeTerminalInterval = 6.0 + ((double)(rand() % 40) / 10.0);
        }
        else if (g_isFakeTerminalActive)
        {
            if (GetTickCount() - g_fakeTerminalStartTime >= 5000)
            {
                g_isFakeTerminalActive = false;
            }
        }

        float timeFactor = (float)(deltaTime * 60.0); 

        for (auto& ball : g_chaosBalls)
        {
            ball.x += ball.vx * timeFactor;
            ball.y += ball.vy * timeFactor;

            if (ball.x <= 0) { ball.x = 0; ball.vx = -ball.vx; }
            if (ball.x + ball.width >= screenWidth) { ball.x = (float)(screenWidth - ball.width); ball.vx = -ball.vx; }
            if (ball.y <= 0) { ball.y = 0; ball.vy = -ball.vy; }
            if (ball.y + ball.height >= screenHeight) { ball.y = (float)(screenHeight - ball.height); ball.vy = -ball.vy; }

            ball.alpha += ball.alphaSpeed * timeFactor;
            if (ball.alpha <= 0.15f) { ball.alpha = 0.15f; ball.alphaSpeed = -ball.alphaSpeed; }
            if (ball.alpha >= 0.95f) { ball.alpha = 0.95f; ball.alphaSpeed = -ball.alphaSpeed; }
        }

        if (g_showSuccess && (GetTickCount() - g_successTimer > 2000))
        {
            g_showSuccess = false;
        }

        InvalidateRect(hwnd, NULL, FALSE);
    }

Cleanup:
    return 0;
}